//package T14.DesignPattern.Ex2;

import java.util.List;

public interface Strategy {
    void sort(List<Integer> list);
}