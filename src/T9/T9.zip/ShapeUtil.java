//package T9;

import java.util.ArrayList;
import java.util.List;

public class ShapeUtil {
    /**
     * In danh sach de nhap vao.
     *
     * @param shapes danh sach shap.
     * @return string.
     */
    public String printInfo(List<GeometricObject> shapes) {
        StringBuilder info = new StringBuilder("");
        info.append("Circle:\n");
        for (GeometricObject i : shapes) {
            if (i instanceof Circle) {
                info.append(i.getInfo());
                info.append("\n");
            }
        }
        info.append("Triangle:\n");
        for (GeometricObject i : shapes) {
            if (i instanceof Triangle) {
                info.append(i.getInfo());
                info.append("\n");
            }
        }
        return info.toString();
    }


}
